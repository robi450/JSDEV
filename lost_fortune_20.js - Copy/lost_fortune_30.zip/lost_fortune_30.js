/*Lost Fortune 2.0
Defending the Fountain of Youth: Game Script
Roberto Torres- Class COP2801-JavaScript
*/
const readlineSync = require('readline-sync');
let score = 0;
let lives = 3;
let lives_lost = 0;
let invaders_killed = 0;
console.log("Welcome to Defending the Fountain of Youth!");
console.log("____________________________________________");
var leaderName = readlineSync.question("Enter your name: ");
console.log("You need to build a team for this game");
console.log("Add more members to your team to help you with this battle")
var fighters = ["Chief Carlos", "Queen Antonia", "Prince Carlos II", "War Chief Felipe"];
for (var i = 0; i < 5; i++); {
    fighters[i] = readlineSync.question("Enter fighter's name: ");
    
    
}
console.log(fighters);
console.log("Your New Team!:");
console.log("________________");
console.log(fighters);
console.log("_________________");

let playAgain = "y";
while (playAgain == "y") {
    survivors = lives - lives_lost;
    console.log("Hey there Chief " + leaderName + "!");
    console.log("A group of brave men and women from the Calusa Tribe fiercly defended their" +
        "\nFountain of Youth Treasure against foreign invasions." + "\nThis great lost treasure " +
        "is believed by many\nto possess super powers including eternal youth and the" +
        "\naquisition of great wealth and happiness." + "\nThe Tribe was led by " + fighters[0] + "," +
        " leader of the Calusa Tribe in the land mass north" + " of the Bahamas." + 
        " Now with your help, "  + leaderName + " " + "and the help of" + " " + fighters[1] + " " + fighters[2] + " " + fighters[3] +  " " + " the Calusas will have" + 
        " more resources to defend their territory." +
        "\nAfter constant deadly attacks, the tribe decides to become more organized" +
        "\nand began to proactively prepare to meet the rude invaders at the coast.");

    console.log("Your mission is to assist the Calusas defend their land ");
    console.log("You have 4 choices to help them, " +
        "please choose wisely as some options will reduce your lives and cost Calusa Lives");
    
    let leader_Backpack = ["bow and arrow"];
    

    console.log("These are your Choices, Choose Wisely...");
    console.log("1 - Map");
    console.log("2 - Canoe");
    console.log("3 - Lance");
    console.log("4 - Spear");

    const choice = parseInt(readlineSync.question("Enter your choice: "));

    switch (choice) {
        case 1:
            console.log("You chose a map that contains instructions and materials " +
                "to build a fortress for the Calusas. You Win!");
            score += 100;
            invaders_killed += 15;
            lives_lost = 0;
            console.log("\tStats\t");
            console.log("*******************");
            console.log("Invaders killed " + invaders_killed);
            console.log("Calusa lives lost " + lives_lost)
            console.log("Score: ", score);
            console.log("lives", lives);
            console.log("*******************");
            break;
        case 2:
            console.log("You chose Chief Carlos canoe and took over the invaders ship. " +
                "Flawless Win!");
            score += 100;
            invaders_killed += 15;
            lives_lost = 0;
            console.log("\tStats\t");
            console.log("*******************");
            console.log("Invaders killed " + invaders_killed);
            console.log("Calusa lives lost " + lives_lost);
            console.log("Score: ", score);
            console.log("lives ", lives);
            console.log("*******************");
            break;
        case 3:
            display_Backpack = "1";
            pick_UpItem = "2";
            console.log("You chose the Lance. Do you want to see what's in your backpack or pick up the Lance?:");
            console.log("1: Display Backpack");
            console.log("2: Pick up item");
            choice_3 = readlineSync.question("Enter your choice: ")
            if (choice_3 == "1") {
                console.log("Backpack inventory" + leader_Backpack);
            }
            
            if (choice_3 == "2") {
                leader_Backpack.push("Lance"); 
            }
            console.log("Great choice, with this lance you stopped the invasion")
            score += 100;  
            lives = 0;
            lives += 1;
            console.log("\tStats\t");
            console.log("*******************");
            console.log("Invaders killed " + invaders_killed);
            console.log("Calusa lives lost " + lives_lost);
            console.log("Score: ", score);
            console.log("lives ", lives);
            console.log("*******************");
            break;
        case 4:
            console.log("You chose the Spear...Do you want to see what's in your backpack or pick up the Spear?:");
            display_Backpack = "1";
            pick_UpItem = "2";
            console.log("You have two choices");
            console.log("1: Display Backpack");
            console.log("2: Pick up item");
            choice_4 = readlineSync.question("Enter your choice: ")
            if (choice_4 == "1"){
                console.log(leader_Backpack);
            }
            if (choice_4 == "2") {
                leader_Backpack.push("Spear"); 

            }
            console.log("Sadly, you got shot by an invader and the Spear was no help...Game Over!");       
            lives = 0;
            lives_lost += 1;
            console.log("\tStats\t");
            console.log("*******************");
            console.log("Invaders killed " + invaders_killed);
            console.log("Calusa lives lost " + lives_lost);
            console.log("Score: ", score);
            console.log("lives ", lives);
            console.log("*******************");
            break;

        default:
            console.log("Invalid selection");


    }
    console.log("Let's check the contents of your back pack")
    console.log(leader_Backpack);
    new_Item = "y";
    if (leader_Backpack > 5) {
        trade_Item = readlineSync.question("Your backpack is full. Would you like to trade for a new item? Enter 'y' for yes: ")

    }
    while (new_Item == "y") {
        console.log("Pick an item:");
        console.log("1: Hacht");
        console.log("2: Snake venom");
        item_Choice = readlineSync.question("Enter your choice: ");
        if (item_Choice == "1") {
            leader_Backpack.push("Hatch");
        
        }
        if (item_Choice == "2") {
            leader_Backpack.push("Snake Venom");
        
        }
    if (leader_Backpack > 5) {
        trade_Item = readlineSync.question("Your backpack is full. Would you like to trade for a new item? Enter 'y' for yes: ")

        console.log("Here's your new backpack");
        console.log(leader_Backpack);
        trade_Item = readlineSync.question("Your backpack is full. Would you like to trade for a new item? Enter 'y' for yes: ")

    }
    console.log(leader_Backpack);
    console.log("Which item would you like to trade?");
    remove = readlineSync.question("Enter item: ");
    leader_Backpack.splice(remove);
        

        
    }
    
     

    

    


console.log("Thanks for playing Lost Fortune 2.0!");
playAgain = readlineSync.question("Would you like to play again(y/n)? ");
console.log("Good Bye!");




}
