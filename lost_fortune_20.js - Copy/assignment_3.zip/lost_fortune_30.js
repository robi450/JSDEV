/*Lost Fortune 2.0
Defending the Fountain of Youth: Game Script
Roberto Torres- Class COP2801-JavaScript
*/
const readlineSync = require('readline-sync');
let score = 0;
let lives = 3;
let lives_lost = 0;
let invaders_killed = 0;
let chief = "Chief Carlos";
let playAgain = "y";
let leader_backpack = ["bow and arrow"];

while (playAgain == "y") {
    survivors = lives - lives_lost;
    console.log("Welcome to Defending the Fountain of Youth!");
    console.log("____________________________________________");
    var leaderName = readlineSync.question("Enter your name: ");
    console.log("Hey there Chief " + leaderName + "!");
    console.log("You need to build a team to help you defend the Calusa's sacred land");
    var team = [];
    var add_Team = readlineSync.question("How may users would you like to add?: ");
    /*while (team < add_Team.length) {
        let players = readlineSync.question("Enter fighter's name: ");
        team.push(players);
        

    }*/
    

    var players = 0;
    for (var i = 0; i < add_Team.length; i++); {
        var players = readlineSync.question("Enter fighter's name: ");
        players += team
        team.push(players);
        
    }   

    console.log("A group of brave men and women from the Calusa Tribe fiercly defended their" +
        "\nFountain of Youth Treasure against foreign invasions." + "\nThis great lost treasure " +
        "is believed by many\nto possess super powers including eternal youth and the" +
        "\naquisition of great wealth and happiness." + "\nThe Tribe was led by " + chief + "," +
        " leader of the Calusa Tribe in the land mass north" + " of the Bahamas." + 
        " Now with your help, "  + leaderName + " " + "and the help of" + " " + team +  " " + " the Calusas will have" + 
        " more resources to defend their territory." +
        "\nAfter constant deadly attacks, the tribe decides to become more organized" +
        "\nand began to proactively prepare to meet the rude invaders at the coast.");
    console.log("Your mission is to assist the Calusas defend their land ");
    console.log("You have 4 choices to help them, " +
        "please choose wisely as some options will reduce your lives and cost " + "Calusa Lives");


    

    console.log("These are your Choices, Choose Wisely...");
    console.log("1 - Map");
    console.log("2 - Canoe");
    console.log("3 - Lance");
    console.log("4 - Spear");

    const choice = parseInt(readlineSync.question("Enter your choice: "));

    switch (choice) {
        case 1:
            console.log("You chose a map that contains instructions and materials " +
                "to build a fortress for the Calusas. You Win!");
            score += 100;
            invaders_killed += 15;
            lives_lost = 0;
            console.log("\tStats\t");
            console.log("*******************");
            console.log("Invaders killed " + invaders_killed);
            console.log("Calusa lives lost " + lives_lost)
            console.log("Score: ", score);
            console.log("lives", lives);
            console.log("*******************");
            break;
        case 2:
            console.log("You chose Chief Carlos canoe and took over the invaders ship. " +
                "Flawless Win!");
            score += 100;
            invaders_killed += 15;
            lives_lost = 0;
            console.log("\tStats\t");
            console.log("*******************");
            console.log("Invaders killed " + invaders_killed);
            console.log("Calusa lives lost " + lives_lost);
            console.log("Score: ", score);
            console.log("lives ", lives);
            console.log("*******************");
            break;
        case 3:

            display_Backpack = "1";
            pick_UpItem = "2";
            console.log("You have two choices");
            console.log("1: Display Backpack");
            console.log("2: Pick up item");
            choice_3 = readlineSync.question("Enter your choice: ")
            if (choice_3 == "1");
            console.log(leader_backpack)
            if (choice_3 == "2");
                leader_backpack.push("lance"); 
            console.log(leader_backpack) 
                
            lives = 0;;
            lives_lost += 1;
            console.log("\tStats\t");
            console.log("*******************");
            console.log("Invaders killed " + invaders_killed);
            console.log("Calusa lives lost " + lives_lost);
            console.log("Score: ", score);
            console.log("lives ", lives);
            console.log("*******************");
            break;
        case 4:
            console.log("You have two choices...");
            display_Backpack = "1";
            pick_UpItem = "2";
            console.log("You have two choices");
            console.log("1: Display Backpack");
            console.log("2: Pick up item");
            choice_4 = readlineSync.question("Enter your choice: ")
            if (choice_4 == "1");
                console.log(leader_backpack)
            if (choice_4 == "2");
                leader_backpack.push("spear");  
                console.log(leader_backpack)
                
            lives = 0;
            lives_lost += 1;
            console.log("\tStats\t");
            console.log("*******************");
            console.log("Invaders killed " + invaders_killed);
            console.log("Calusa lives lost " + lives_lost);
            console.log("Score: ", score);
            console.log("lives ", lives);
            console.log("*******************");
            break;

        default:
            console.log("Invalid selection");


    }


    console.log("Thanks for playing Lost Fortune 2.0!");
    playAgain = readlineSync.question("Would you like to play again(y/n)? ");



}
console.log("Got it, Good Bye!");
