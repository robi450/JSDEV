//GameConsole.js
const readlineSync = require('readline-sync');
const Game = require("./Game");

class GameConsole {
    constructor() {
    }
    load(name) {
        if (name == "Lost Fortune") {
            var gameName = new Game(name);
            gameName.play();
        }
        else{
            console.log("Sorry, that game is not available");
        }
    }
    turnOn() {
        console.log("Welcome to Lost Fortune!™️" + " ♛");
        var choice = parseInt(readlineSync.question("Press 1 to load, Press 2 to turn off: "));
        switch (choice) {
            case 1:
                var gameChoice = readlineSync.question("Enter the game's name: ");
                var start = new GameConsole();
                start.load(gameChoice);
            case 2:
                console.log("Goodbye");
            break;
        }   
    }
};

var startGame = new GameConsole();
startGame.turnOn();








